function StopTrigger_3_compare(R, pngFile)
% Stage 3: LDR vs phototransistor vs photodiode on one clock. Distance is measured from the ideal trip point (T = 0.5).
if nargin < 1, R = StopTrigger_3_report(); end   % no input: reuse the last results, or run the bench
if nargin < 2, pngFile = fullfile(fileparts(mfilename('fullpath')), 'StopTrigger_3_compare.png'); end
st = StopTrigger_3_style();
o = R.out; mw = get_param('StopTrigger_Bench_3','ModelWorkspace');
t0 = getVariable(mw,'t0'); tau = getVariable(mw,'tau'); Ts = getVariable(mw,'Tstart'); Te = getVariable(mw,'Tend'); Tt = getVariable(mw,'Ttrip');
tI = R.tIdeal;                                    % time the light crosses T = 0.5
tg = R.tags; nm = R.names; K = numel(tg);
col = {st.LDR, st.PT, st.PD}; ls = {'-', '-', '--'};   % photodiode dashed: it sits on top of the phototransistor
tStopAll = cellfun(@(s) R.(s).tStopped, tg);
xl = [tI-0.2 max(tStopAll)+0.15];
xp = cellfun(@(s) R.(s).xPastIdeal*1e3, tg); lag = cellfun(@(s) R.(s).lag_ms, tg);
[~, iBest] = min(abs(xp)); [~, iWorst] = max(abs(xp));

f = st.figure('Stage 3: sensor comparison', [1300 1150]);
tl = tiledlayout(f, 4, 1, 'TileSpacing', 'loose', 'Padding', 'compact');
best = find(abs(abs(xp) - abs(xp(iBest))) < 0.5);           % sensors tied for best
bestNames = strjoin(cellfun(@(s) [upper(s(1)) s(2:end)], nm(best), 'uni', 0), ' and ');
verb = 'stops'; if numel(best) > 1, verb = 'both stop'; end
worstName = nm{iWorst}; if ~strcmp(worstName, 'LDR'), worstName = lower(worstName); end
st.title(tl, sprintf('%s %s %.0f mm closer to the target than the %s', bestNames, verb, abs(xp(iWorst)) - abs(xp(iBest)), worstName), ...
  'Same light, same car. Each sensor decides when to cut the motor; after that the car coasts the same distance.');
T = @(t) Te + (Ts-Te)./(1+exp((t-t0)/tau));
tt = linspace(xl(1), xl(2), 600);

ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
plot(ax, tt, T(tt), 'Color', st.ink2, 'LineWidth', st.lw, 'DisplayName', 'Light through the jar');
yline(ax, Tt, ':', 'Color', st.ref, 'LineWidth', 1.2, 'HandleVisibility', 'off');
st.label(ax, xl(1), Tt, ' trip level', 'HorizontalAlignment', 'left', 'VerticalAlignment', 'top');
xline(ax, tI, '--', 'Color', st.ref, 'LineWidth', 1.2, 'DisplayName', 'Ideal moment to stop');
for k = 1:K
  xline(ax, R.(tg{k}).tStop, ls{k}, 'Color', col{k}, 'LineWidth', st.lw, 'DisplayName', sprintf('%s fires STOP (%+.0f ms)', nm{k}, lag(k)));
end
xlim(ax, xl); ylabel(ax, 'Light (1 = clear)'); title(ax, '1  The jar darkens; each sensor fires STOP at its own moment'); st.legend(ax, 'northeast');

ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
for k = 1:K, C = o.(['Car_' tg{k}]); plot(ax, C.Time, C.Data(:,1)*1e3, ls{k}, 'Color', col{k}, 'LineWidth', st.lw, 'DisplayName', nm{k}); end
xline(ax, tI, '--', 'Color', st.ref, 'LineWidth', 1.2, 'HandleVisibility', 'off');
vmax = max(cellfun(@(s) max(o.(['Car_' s]).Data(:,1)), tg))*1e3;
xlim(ax, xl); ylim(ax, [0 vmax*1.2]); ylabel(ax, 'Car speed [mm/s]'); st.legend(ax, 'northeast');
title(ax, '2  A sensor that fires later keeps the car moving longer');

ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
for k = 1:K
  C = o.(['Car_' tg{k}]); x0 = interp1(C.Time, C.Data(:,2), tI);
  plot(ax, C.Time, (C.Data(:,2)-x0)*1e3, ls{k}, 'Color', col{k}, 'LineWidth', st.lw, 'DisplayName', nm{k});
end
yline(ax, 0, '-', 'Color', st.ref, 'LineWidth', 1, 'HandleVisibility', 'off');
xline(ax, tI, '--', 'Color', st.ref, 'LineWidth', 1.2, 'HandleVisibility', 'off');
xlim(ax, xl); ylabel(ax, 'Past the ideal point [mm]'); xlabel(ax, 'Time [s]'); st.legend(ax, 'southeast');
title(ax, '3  Distance travelled past the ideal stopping point');

ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
b = barh(ax, 1:K, xp, 0.55, 'FaceColor', 'flat', 'EdgeColor', 'none'); b.CData = vertcat(col{:});
for k = 1:K
  st.label(ax, xp(k), k, sprintf('  %.1f mm   (STOP %+.0f ms vs ideal)', xp(k), lag(k)), 'VerticalAlignment', 'middle', 'Color', st.ink, 'FontSize', 11);
end
ax.YTick = 1:K; ax.YTickLabel = nm; ax.YDir = 'reverse'; ax.YGrid = 'off';
xlim(ax, [0 max(xp)*1.55]); xlabel(ax, 'Stops past the ideal point [mm]   (shorter is better)');
title(ax, '4  Summary: where each car comes to rest');
st.export(f, pngFile);
end
