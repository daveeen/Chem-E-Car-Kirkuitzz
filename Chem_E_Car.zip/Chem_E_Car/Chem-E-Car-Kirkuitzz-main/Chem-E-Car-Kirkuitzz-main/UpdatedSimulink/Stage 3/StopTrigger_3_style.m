function S = StopTrigger_3_style()
% Shared look for all Stage 3 figures (presentation quality, colourblind-safe).
% Each sensor keeps one colour in every figure. Palette checked for colour-vision deficiency.
%   S = StopTrigger_3_style();  f = S.figure('Name', [w h]);  S.axes(ax);  S.title(tl, 'Headline', 'subtitle');
S.LDR  = hex('#1baf7a');     % aqua
S.PT   = hex('#2a78d6');     % blue
S.PD   = hex('#eb6834');     % orange
S.ref  = hex('#8a8a85');     % reference lines, ideal moment, current design
S.ink  = hex('#1f1f1d');     % primary text
S.ink2 = hex('#5c5c57');     % secondary text
S.grid = hex('#e6e6e1');
S.bg   = hex('#fcfcfb');
S.font = 'Arial';
S.lw   = 2.2;
S.figure = @(name, sz) makeFigure(S, name, sz);
S.axes   = @(ax) styleAxes(S, ax);
S.title  = @(tl, head, sub) styleTitle(S, tl, head, sub);
S.legend = @(ax, loc) styleLegend(S, ax, loc);
S.label  = @(ax, x, y, str, varargin) text(ax, x, y, str, 'Color', S.ink2, 'FontName', S.font, 'FontSize', 10, varargin{:});
S.export = @(f, file) exportClean(S, f, file);
end

function f = makeFigure(S, name, sz)
f = figure('Name', name, 'Color', S.bg, 'Position', [60 40 sz]);
try, theme(f, 'light'); catch, end
set(f, 'DefaultAxesFontName', S.font, 'DefaultTextFontName', S.font);
end

function styleAxes(S, ax)
set(ax, 'Box', 'off', 'Color', S.bg, 'FontName', S.font, 'FontSize', 11, 'LineWidth', 0.8, ...
    'XColor', S.ink2, 'YColor', S.ink2, 'GridColor', S.grid, 'GridAlpha', 1, 'TickDir', 'out', 'TickLength', [0.006 0.006]);
grid(ax, 'on'); ax.XMinorGrid = 'off'; ax.YMinorGrid = 'off';
ax.Title.FontSize = 13; ax.Title.FontWeight = 'bold'; ax.Title.Color = S.ink;
ax.Title.HorizontalAlignment = 'left'; ax.TitleHorizontalAlignment = 'left';
ax.XLabel.Color = S.ink2; ax.YLabel.Color = S.ink2; ax.XLabel.FontSize = 11; ax.YLabel.FontSize = 11;
end

function styleTitle(S, tl, head, sub)
title(tl, head, 'FontName', S.font, 'FontSize', 18, 'FontWeight', 'bold', 'Color', S.ink);
if nargin > 3 && ~isempty(sub)
  subtitle(tl, sub, 'FontName', S.font, 'FontSize', 12, 'Color', S.ink2);
end
end

function lg = styleLegend(S, ax, loc)
lg = legend(ax, 'Location', loc, 'Box', 'off', 'FontName', S.font, 'FontSize', 10, 'TextColor', S.ink);
end

function c = hex(h)
c = sscanf(h(2:end), '%2x%2x%2x', [1 3])/255;
end

function exportClean(S, f, file)
ax = findall(f, 'Type', 'axes');
for i = 1:numel(ax), try, ax(i).Toolbar.Visible = 'off'; catch, end, end
exportgraphics(f, file, 'Resolution', 200, 'BackgroundColor', S.bg);
end
