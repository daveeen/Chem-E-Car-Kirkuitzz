function S = StopTrigger_3_signals()
% Why the photodiode needs an amplifier and the phototransistor does not (LDR shown for contrast).
%   S = StopTrigger_3_signals();     % 3 simulations (~1 min) + offline noise test, draws the figure
%
% A phototransistor is a photodiode with a transistor built in: the light makes a small base
% current and the transistor multiplies it by its gain (BF = 100 here). An LDR is a resistor fed
% from the supply, so it gives volts directly. A photodiode has no gain, so its microamps must be
% turned into volts by a large resistor or an amplifier before the comparator, whose hysteresis
% and offsets are fixed in volts.
%
% Runs: the three sensors as built, plus the photodiode on the same 10 kOhm resistor as the LDR
% with no amplifier and with a xGamp amplifier. Electrical noise from the motor and relay is then
% added at the comparator input to see how far the stopping point scatters.

run('StopTrigger_3_params.m');
vRun = v;                                          % car running speed from the params estimate [m/s]
bn = 'StopTrigger_Bench_3';
mw = get_param(bn,'ModelWorkspace');
gv = @(n) getVariable(mw,n);
Rin = gv('Rin'); Rh = gv('Rhyst'); Tt = gv('Ttrip'); Kpd = gv('Kpd'); Phi = gv('PhiPD');
Vcc = gv('Vcc'); Rfix = gv('Rfix'); Ipk = gv('Ipk'); GLDR = gv('GLDR'); Rpu = gv('RpuPT'); RpdDesign = gv('Rpd');
q = find_system([bn '/Phototransistor stage'],'SearchDepth',1,'Name','Phototransistor (NPN)');
BF = str2double(get_param(q{1},'BF'));
hyst = Vcc*Rin/(Rin+Rh);                           % comparator hysteresis width [V]
Gamp = round(0.8*Vcc/(Kpd*Phi*Rfix));              % amplifier gain that fills ~80% of the supply in a clear jar

% Photodiode configurations: load resistor and amplifier gain
cfg = struct('name', {'Photodiode, 10 k\Omega, no amp', sprintf('Photodiode, 10 k\\Omega, \\times%d amp', Gamp), ...
                      sprintf('Photodiode, %.0f k\\Omega, no amp (current design)', RpdDesign/1e3)}, ...
             'R', {Rfix, Rfix, RpdDesign}, 'G', {1, Gamp, 1});
in = repmat(Simulink.SimulationInput(bn), 1, numel(cfg));
for c = 1:numel(cfg)
  VrefD = Kpd*Phi*Tt*cfg(c).R*cfg(c).G*(Rin+Rh)/Rh;   % trip at the same light level
  in(c) = in(c).setVariable('Rpd', cfg(c).R, 'Workspace', bn).setVariable('GPD', cfg(c).G, 'Workspace', bn) ...
               .setVariable('VrefD', VrefD, 'Workspace', bn);
end
fprintf('Running %d simulations (about 25 s each)...\n', numel(in));
out = sim(in, 'ShowProgress', 'off', 'ShowSimulationManager', 'off');

% Collect signals. Light T without noise, for plotting against light level
[tT, T] = tsData(out(1).Tsig);
sig = struct();
[t, vs] = tsData(out(1).PT.Vs); [~, va] = tsData(out(1).PT.Va);
sig(1).name = sprintf('Phototransistor, %.1f k\\Omega pull-up', Rpu/1e3); sig(1).t = t; sig(1).Vs = vs; sig(1).Va = va;
sig(1).G = 1; sig(1).Q = out(1).S2_PT.Q;
for c = 1:numel(cfg)
  [t, vs] = tsData(out(c).PD.Vs); [~, va] = tsData(out(c).PD.Va);
  sig(c+1).name = cfg(c).name; sig(c+1).t = t; sig(c+1).Vs = vs; sig(c+1).Va = va;
  sig(c+1).G = cfg(c).G; sig(c+1).Q = out(c).S2_PD.Q;
end
[t, vs] = tsData(out(1).LDR.Vs); [~, va] = tsData(out(1).LDR.Va);   % LDR as built: divider + gain stage
sig(5).name = sprintf('LDR, 10 k\\Omega divider + \\times%.1f gain', GLDR); sig(5).t = t; sig(5).Vs = vs; sig(5).Va = va;
sig(5).G = GLDR; sig(5).Q = out(1).S2_LDR.Q;
for k = 1:numel(sig)
  sig(k).Tl = interp1(tT, T, sig(k).t);                       % light level at each sample
  sig(k).tStop = sig(k).Q.Time(find(sig(k).Q.Data > Vcc/2, 1));
  sig(k).thr = interp1(sig(k).t, sig(k).Va, sig(k).tStop);    % comparator input at the trip
  sig(k).dir = sign(interp1(sig(k).t, sig(k).Va, sig(k).tStop + 0.05) - interp1(sig(k).t, sig(k).Va, sig(k).tStop - 0.05));
  sig(k).thrRaw = sig(k).thr/sig(k).G;                         % same trip point before any gain stage
  clear0 = sig(k).Tl > 0.95;                                   % clear jar
  sig(k).swing = abs(mean(sig(k).Va(clear0)) - sig(k).thr);    % how far the signal moves from clear to trip [V]
  sig(k).swingRaw = sig(k).swing/sig(k).G;                     % the same, straight from the sensor
  near = abs(sig(k).Tl - Tt) < 0.05;
  p = polyfit(sig(k).Tl(near), sig(k).Va(near), 1); sig(k).slope = abs(p(1));   % V per unit of light at the trip
end

% Offline electrical-noise test: motor/relay noise in volts on the comparator input
noiseRMS = [0.005 0.02 0.05]; nTrial = 200; dt = 1e-3; rng(1);
tg = (0:dt:sig(1).t(end))';
for k = 1:numel(sig)
  vaU = interp1(sig(k).t, sig(k).Va, tg);
  i0 = find(sig(k).dir*(vaU - sig(k).thr) >= 0 & tg > 0.5, 1); t0k = tg(i0);
  err = nan(nTrial, numel(noiseRMS)); falseTrip = zeros(1, numel(noiseRMS));
  for j = 1:numel(noiseRMS)
    for n = 1:nTrial
      vn = vaU + noiseRMS(j)*randn(size(tg));
      i1 = find(sig(k).dir*(vn - sig(k).thr) >= 0, 1);
      if tg(i1) < t0k - 0.5, falseTrip(j) = falseTrip(j) + 1; end
      err(n, j) = (tg(i1) - t0k)*vRun*1e3;                    % stop position shift [mm]
    end
  end
  sig(k).noiseErr = err; sig(k).falseTrip = falseTrip;
end

S = struct('sig', sig, 'noiseRMS', noiseRMS, 'hyst', hyst, 'BF', BF, 'Ipk', Ipk, 'Kpd', Kpd, 'Phi', Phi, ...
           'Ald', gv('Ald'), 'gam', gv('gam'), 'Vcc', Vcc, 'Rfix', Rfix, 'GLDR', GLDR, 'Gamp', Gamp, 'Rpu', Rpu);
plotSignals(S, Tt);
printTable(S, Tt);
end

function [t, d] = tsData(x)
if isa(x, 'timeseries'), t = x.Time; d = x.Data(:);
elseif isstruct(x) && isfield(x, 'signals'), t = x.time; d = x.signals.values(:);
else, t = x.Time; d = x.Data(:);
end
end

function plotSignals(S, Tt)
sig = S.sig; st = StopTrigger_3_style();
iPT = 1; iPDn = 2; iPDa = 3; iLDR = 5;
f = st.figure('Stage 3: why the photodiode needs an amplifier', [1400 1050]);
tl = tiledlayout(f, 2, 2, 'TileSpacing', 'loose', 'Padding', 'compact');
st.title(tl, 'A photodiode needs an amplifier. A phototransistor has one built in.', ...
  sprintf(['Same light, same %.1f V supply, same comparator. The LDR and phototransistor give volts on their own; ' ...
  'the photodiode''s tiny current must be amplified first.'], S.Vcc));
Tg = linspace(1, 0.1, 200);
xlab = 'Light reaching the sensor   (1 = clear jar  \rightarrow  darker)';
ytop = S.Vcc*1.32;                                  % headroom for the legend

% 1. Raw currents
ax = nexttile(tl); hold(ax, 'on'); st.axes(ax); set(ax, 'YScale', 'log', 'XDir', 'reverse');
iJ = S.Ipk*Tg*1e6; iC = S.BF*S.Ipk*Tg*1e6; iD = S.Kpd*S.Phi*Tg*1e6;
iL = S.Vcc./(S.Ald*Tg.^(-S.gam) + S.Rfix)*1e6;
plot(ax, Tg, iC, '-', 'Color', st.PT, 'LineWidth', st.lw, 'DisplayName', sprintf('Phototransistor output (\\times%d built-in gain)', S.BF));
plot(ax, Tg, iJ, ':', 'Color', st.PT, 'LineWidth', st.lw, 'DisplayName', 'Phototransistor light-sensing junction');
plot(ax, Tg, iL, '-', 'Color', st.LDR, 'LineWidth', st.lw, 'DisplayName', sprintf('LDR (resistor fed from the %.1f V supply)', S.Vcc));
plot(ax, Tg, iD, '-', 'Color', st.PD, 'LineWidth', st.lw, 'DisplayName', 'Photodiode output (no gain)');
xline(ax, Tt, '--', 'Color', st.ref, 'LineWidth', 1, 'HandleVisibility', 'off');
k = find(Tg <= Tt, 1); yv = [iC(k) iL(k) iD(k)];
va = {'bottom', 'top', 'top'};                                % keep close labels apart
if yv(1) < yv(2), va(1:2) = va([2 1]); end
for m = 1:3
  st.label(ax, Tg(k)-0.02, yv(m), sprintf('%.0f \\muA', yv(m)), 'VerticalAlignment', va{m}, 'FontWeight', 'bold', 'Color', st.ink);
end
st.label(ax, Tt, 1.15, ' trip level', 'VerticalAlignment', 'bottom');
ylim(ax, [1 30000]); ax.YTick = [1 10 100 1000 10000]; ax.YTickLabel = {'1','10','100','1000',''};
xlabel(ax, xlab); ylabel(ax, 'Sensor current [\muA, log scale]');
title(ax, sprintf('1  The photodiode makes about %.0f\\times less current', iC(k)/iD(k)));
lg = st.legend(ax, 'north'); lg.NumColumns = 2;

% 2. Straight from each sensor, no amplifier
ax = nexttile(tl); hold(ax, 'on'); st.axes(ax); set(ax, 'XDir', 'reverse');
drawSig(ax, st, sig(iLDR), st.LDR, '-', S.hyst, 'LDR, 10 k\Omega divider', true);
drawSig(ax, st, sig(iPT), st.PT, '-', S.hyst, sprintf('Phototransistor, %.1f k\\Omega', S.Rpu/1e3), true);
drawSig(ax, st, sig(iPDn), st.PD, '--', S.hyst, 'Photodiode, 10 k\Omega', true);
xline(ax, Tt, '--', 'Color', st.ref, 'LineWidth', 1, 'HandleVisibility', 'off'); ylim(ax, [-0.1 ytop]);
st.label(ax, 0.12, sig(iPDn).thrRaw + 0.1, sprintf(['Photodiode moves only %.2f V before the trip:\n' ...
  'the %.0f mV hysteresis band (shaded) is %.0f%% of it'], sig(iPDn).swingRaw, S.hyst*1e3, 100*S.hyst/sig(iPDn).swingRaw), ...
  'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom', 'FontSize', 10, 'Color', st.ink, 'BackgroundColor', st.bg, 'Margin', 1);
xlabel(ax, xlab); ylabel(ax, 'Sensor output voltage [V]');
title(ax, '2  Straight from the sensor: the photodiode barely moves');
st.legend(ax, 'northeast');

% 3. With amplifiers
ax = nexttile(tl); hold(ax, 'on'); st.axes(ax); set(ax, 'XDir', 'reverse');
drawSig(ax, st, sig(iLDR), st.LDR, '-', S.hyst, sprintf('LDR + \\times%.1f gain   (%.1f V swing)', S.GLDR, sig(iLDR).swing), false);
drawSig(ax, st, sig(iPT), st.PT, '-', S.hyst, sprintf('Phototransistor, no amplifier   (%.1f V swing)', sig(iPT).swing), false);
drawSig(ax, st, sig(iPDa), st.PD, '-', S.hyst, sprintf('Photodiode + \\times%d amplifier   (%.1f V swing)', S.Gamp, sig(iPDa).swing), false);
xline(ax, Tt, '--', 'Color', st.ref, 'LineWidth', 1, 'HandleVisibility', 'off'); ylim(ax, [-0.1 ytop]);
xlabel(ax, xlab); ylabel(ax, 'Voltage at the comparator [V]');
title(ax, sprintf('3  With a \\times%d amplifier, the photodiode matches the others', S.Gamp));
st.legend(ax, 'northeast');

% 4. Electrical noise at the comparator input
ax = nexttile(tl); hold(ax, 'on'); st.axes(ax);
idx = [iLDR iPT iPDn iPDa];
cols = {st.LDR, st.PT, st.PD, st.PD}; face = {st.LDR, st.PT, st.bg, st.PD};
nm = {sprintf('LDR (+\\times%.1f gain)', S.GLDR), 'Phototransistor', 'Photodiode, no amplifier', sprintf('Photodiode + \\times%d amplifier', S.Gamp)};
w = 0.19; x0 = 1:numel(S.noiseRMS); ymax = 0; ymin = 0;
for m = 1:numel(idx)
  s = sig(idx(m)); e = s.noiseErr; lo = prctile(e, 5); hi = prctile(e, 95); md = median(e); xk = x0 + (m-2.5)*w;
  for j = 1:numel(x0)
    plot(ax, [xk(j) xk(j)], [lo(j) hi(j)], '-', 'Color', cols{m}, 'LineWidth', 6, 'HandleVisibility', 'off');
    if s.falseTrip(j) > 0
      st.label(ax, xk(j), lo(j), sprintf('%d%%\nfalse\nstops', round(100*s.falseTrip(j)/size(e,1))), 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'FontSize', 9, 'FontWeight', 'bold', 'Color', st.ink);
    end
  end
  plot(ax, xk, md, 'o', 'MarkerSize', 9, 'LineWidth', 2, 'Color', cols{m}, 'MarkerFaceColor', face{m}, 'DisplayName', nm{m});
  ymax = max([ymax hi]); ymin = min([ymin lo]);
end
yline(ax, 0, '-', 'Color', st.ref, 'LineWidth', 1, 'HandleVisibility', 'off');
ax.XTick = x0; ax.XTickLabel = compose('%.0f mV', S.noiseRMS*1e3); xlim(ax, [0.5 numel(x0)+0.5]);
ylim(ax, [ymin*1.4 - 10, max(ymax, 10)*1.2]);
xlabel(ax, 'Electrical noise from the motor and relay (RMS)'); ylabel(ax, 'Shift in stopping point [mm]  (bar = 90% of runs)');
title(ax, '4  With motor noise, the unamplified photodiode stops at random');
st.legend(ax, 'southwest');
st.export(f, fullfile(fileparts(mfilename('fullpath')), 'StopTrigger_3_signals.png'));
end

function drawSig(ax, st, s, c, ls, hyst, name, raw)
if raw, y = s.Vs; thr = s.thrRaw; else, y = s.Va; thr = s.thr; end
yb = thr + [0 -s.dir*hyst];                                   % hysteresis band beside the threshold
patch(ax, [1 0.1 0.1 1], [yb(1) yb(1) yb(2) yb(2)], c, 'FaceAlpha', 0.14, 'EdgeColor', 'none', 'HandleVisibility', 'off');
yline(ax, thr, ':', 'Color', c, 'LineWidth', 1.2, 'HandleVisibility', 'off');
plot(ax, s.Tl, y, ls, 'Color', c, 'LineWidth', st.lw, 'DisplayName', name);
end

function printTable(S, Tt)
sig = S.sig(:)'; order = [5 1 2 3 4];
fprintf('\nWhy the photodiode needs an amplifier (%.1f V supply, trip at T = %.2f, comparator hysteresis %.0f mV)\n', S.Vcc, Tt, S.hyst*1e3);
fprintf('%-46s %11s %11s %12s %12s %16s %12s\n', '', 'Sensor', 'At comp.', 'Slope', 'Hyst/swing', 'Scatter @20mV', 'False stops');
fprintf('%-46s %11s %11s %12s %12s %16s %12s\n', '', 'swing [V]', 'swing [V]', '[mV per 1%]', '', '[mm, 5-95%]', '@50 mV');
for k = order
  e = sig(k).noiseErr(:,2);
  fprintf('%-46s %11.2f %11.2f %12.1f %11.0f%% %16.1f %11.0f%%\n', strrep(strrep(strrep(sig(k).name,'\Omega','ohm'),'\times','x'),' (current design)','*'), ...
    sig(k).swingRaw, sig(k).swing, sig(k).slope*10, 100*S.hyst/sig(k).swing, prctile(e,95)-prctile(e,5), 100*sig(k).falseTrip(3)/size(sig(k).noiseErr,1));
end
fprintf('* the current design gets its gain from a %.0fx larger resistor instead of an op-amp.\n', sig(4).swingRaw/sig(2).swingRaw);
fprintf('Phototransistor collector current = %d x its own photocurrent (built-in transistor gain).\n', S.BF);
end
