function StopTrigger_3_tests_plot(T, pngFile)
% Figure and summary table for StopTrigger_3_tests. With no input, loads the saved results.
if nargin < 1
  S = load(fullfile(fileparts(mfilename('fullpath')), 'StopTrigger_3_tests_results.mat')); T = S.T;
end
if nargin < 2, pngFile = fullfile(fileparts(mfilename('fullpath')), 'StopTrigger_3_tests.png'); end
st = StopTrigger_3_style();
col = {st.LDR, st.PT, st.PD}; mk = {'o','s','^'}; ls = {'-', '-', '--'};
tg = T.tags; nm = T.names; K = numel(tg);
tests = intersect({'tolerance','supply','noise'}, fieldnames(T), 'stable');
summ = struct();

% Summary numbers first, so the headline can quote them
if isfield(T,'tolerance')
  R = T.tolerance; ok = ~R.atStart & ~R.never;
  for k = 1:K
    tolf = T.TOL.(tg{k}); gv = R.g(ok(:,k)); xv = R.xPast(ok(:,k),k);
    if 1 - tolf < min(gv) - 1e-9, summ.(tg{k}).tolSpread = Inf;
    else, summ.(tg{k}).tolSpread = abs(interp1(gv, xv, 1+tolf) - interp1(gv, xv, 1-tolf)); end
    summ.(tg{k}).perTen = (interp1(R.g, R.xPast(:,k), 1.15) - interp1(R.g, R.xPast(:,k), 0.85))/3;
  end
end
if isfield(T,'supply')
  for k = 1:K, summ.(tg{k}).supplySpread = abs(T.supply.xPast(end,k) - T.supply.xPast(1,k)); end
end
if isfield(T,'noise')
  R = T.noise; lev = R.levels;
  for k = 1:K
    v0 = R.xPast(abs(R.sigN - lev(1)) < 1e-12, k); v1 = R.xPast(abs(R.sigN - lev(end)) < 1e-12, k);
    summ.(tg{k}).noiseSpread = max(v1) - min(v1); summ.(tg{k}).noiseShift = mean(v1) - mean(v0);
    summ.(tg{k}).earlyTrips = nnz(R.tStop(:,k) < T.tIdeal - 0.02 & R.sigN(:) > 0); summ.(tg{k}).noisyRuns = nnz(R.sigN > 0);
  end
end

f = st.figure('Stage 3: sensor robustness tests', [1300 380*numel(tests)+120]);
tl = tiledlayout(f, numel(tests), 1, 'TileSpacing', 'loose', 'Padding', 'compact');
st.title(tl, 'Real parts vary: the photodiode is the most repeatable sensor', ...
  'Where the car stops relative to the ideal point when parts, supply voltage and light noise vary. Flatter lines and tighter bars are better.');

if isfield(T,'tolerance')
  R = T.tolerance; pct = (R.g - 1)*100;
  ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
  ok = ~R.atStart & ~R.never; y = R.xPast; y(~ok) = NaN;
  lo = min(y(:)) - 30; hi = max(y(:)) + 65;
  for k = 1:K
    plot(ax, pct, y(:,k), [ls{k} mk{k}], 'Color', col{k}, 'LineWidth', st.lw, 'MarkerSize', 8, 'MarkerFaceColor', col{k}, 'DisplayName', nm{k});
    bad = R.atStart(:,k);
    if any(bad), plot(ax, pct(bad), repmat(lo + 6 + 5*k, 1, nnz(bad)), 'x', 'Color', col{k}, 'MarkerSize', 12, 'LineWidth', 2.5, 'HandleVisibility', 'off'); end
    tol = T.TOL.(tg{k})*100; yb = hi - 16*k;                         % typical spread of this part
    plot(ax, [-tol tol], [yb yb], '-', 'Color', col{k}, 'LineWidth', 6, 'HandleVisibility', 'off');
    if isinf(summ.(tg{k}).tolSpread), sp = 'some parts stop at the start line';
    else, sp = sprintf('stop spread %.0f mm', summ.(tg{k}).tolSpread); end
    st.label(ax, -tol, yb + 2, sprintf('typical %s parts \\pm%.0f%%:  %s', nm{k}, tol, sp), 'VerticalAlignment', 'bottom', 'Color', st.ink);
  end
  if any(R.atStart(:)), st.label(ax, min(pct) + 2, lo + 16, '\leftarrow \times = STOP fires at the start line', 'VerticalAlignment', 'middle'); end
  xline(ax, 0, ':', 'Color', st.ref, 'HandleVisibility', 'off'); ylim(ax, [lo hi]); xlim(ax, [min(pct)-2 max(pct)+2]);
  xlabel(ax, 'Sensor sensitivity vs the nominal part [%]   (+ = reads brighter)'); ylabel(ax, 'Stops past ideal [mm]');
  title(ax, '1  Part-to-part spread: the circuit is tuned for a nominal part'); st.legend(ax, 'southeast');
end

if isfield(T,'supply')
  R = T.supply; ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
  for k = 1:K
    plot(ax, R.Vcc, R.xPast(:,k), [ls{k} mk{k}], 'Color', col{k}, 'LineWidth', st.lw, 'MarkerSize', 8, 'MarkerFaceColor', col{k}, ...
      'DisplayName', sprintf('%s  (spread %.0f mm)', nm{k}, summ.(tg{k}).supplySpread));
  end
  xline(ax, mean(R.Vcc), ':', 'Color', st.ref, 'HandleVisibility', 'off');
  xlabel(ax, 'Stop-circuit supply [V]   (comparator reference held fixed)'); ylabel(ax, 'Stops past ideal [mm]');
  title(ax, '2  Supply drifts \pm10%: only the photodiode ignores it'); st.legend(ax, 'best');
end

if isfield(T,'noise')
  R = T.noise; ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
  lev = R.levels; off = (lev(end) - lev(1))*0.025*[-1 0 1];
  for k = 1:K
    mn = nan(size(lev)); lo = mn; hi = mn;
    for j = 1:numel(lev)
      v = R.xPast(abs(R.sigN - lev(j)) < 1e-12, k); v = v(~isnan(v));
      if isempty(v), continue, end
      mn(j) = mean(v); lo(j) = min(v); hi(j) = max(v);
      plot(ax, [1 1]*(lev(j)+off(k)), [lo(j) hi(j)], '-', 'Color', col{k}, 'LineWidth', 6, 'HandleVisibility', 'off');
    end
    plot(ax, lev+off(k), mn, [ls{k} mk{k}], 'Color', col{k}, 'LineWidth', st.lw, 'MarkerSize', 8, 'MarkerFaceColor', col{k}, ...
      'DisplayName', sprintf('%s  (%d of %d noisy runs stopped early)', nm{k}, summ.(tg{k}).earlyTrips, summ.(tg{k}).noisyRuns));
  end
  ax.XTick = lev; xlabel(ax, 'Light noise level (standard deviation of light, 1 = clear)'); ylabel(ax, 'Stops past ideal [mm]');
  title(ax, sprintf('3  Light flicker: the LDR''s slow response filters it out  (bars = range over %d noise seeds)', max(R.seed)));
  st.legend(ax, 'best');
end
st.export(f, pngFile);

% Summary table
fprintf('\n%-38s %12s %16s %12s\n', 'Robustness summary', 'LDR', 'Phototransistor', 'Photodiode');
row = @(lab, fld, fmt) fprintf('%-38s %12s %16s %12s\n', lab, fmtv(summ, tg{1}, fld, fmt), fmtv(summ, tg{2}, fld, fmt), fmtv(summ, tg{3}, fld, fmt));
if isfield(T,'tolerance')
  fprintf('%-38s %12s %16s %12s\n', 'Typical sensitivity spread', sprintf('+/-%.0f%%',T.TOL.LDR*100), sprintf('+/-%.0f%%',T.TOL.PT*100), sprintf('+/-%.0f%%',T.TOL.PD*100));
  row('Stop shift per 10% sensitivity [mm]', 'perTen', '%.1f');
  row('Stop spread over typical parts [mm]', 'tolSpread', '%.1f');
end
if isfield(T,'supply'), row(sprintf('Stop spread, supply %.2f-%.2f V [mm]', T.supply.Vcc(1), T.supply.Vcc(end)), 'supplySpread', '%.1f'); end
if isfield(T,'noise')
  row(sprintf('Stop scatter at noise %.2f [mm]', T.noise.levels(end)), 'noiseSpread', '%.1f');
  row(sprintf('Mean shift at noise %.2f [mm]', T.noise.levels(end)), 'noiseShift', '%+.1f');
  fprintf('%-38s %12s %16s %12s\n', 'Early trips from noise (of noisy runs)', ...
    sprintf('%d/%d', summ.LDR.earlyTrips, summ.LDR.noisyRuns), sprintf('%d/%d', summ.PT.earlyTrips, summ.PT.noisyRuns), sprintf('%d/%d', summ.PD.earlyTrips, summ.PD.noisyRuns));
end
fprintf('(Inf = some typical parts fire STOP at the start line. Figure saved to %s)\n', pngFile);
end

function s = fmtv(summ, tag, fld, fmt)
if ~isfield(summ, tag) || ~isfield(summ.(tag), fld), s = '-'; return, end
v = summ.(tag).(fld);
if isinf(v), s = 'Inf'; else, s = sprintf(fmt, v); end
end
