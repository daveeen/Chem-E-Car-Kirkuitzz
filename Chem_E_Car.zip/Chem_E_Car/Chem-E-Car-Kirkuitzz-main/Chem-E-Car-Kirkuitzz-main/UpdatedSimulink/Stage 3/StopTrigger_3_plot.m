function StopTrigger_3_plot(R, pngFile)
% Stage 3 figure: speed, motor current and distance travelled, timed from STOP.
% After STOP the car is the same for all three sensors, so one set of curves is drawn (phototransistor).
if nargin < 1, R = StopTrigger_3_report(); end   % no input: reuse the last results, or run the bench
if nargin < 2, pngFile = fullfile(fileparts(mfilename('fullpath')), 'StopTrigger_3_plot.png'); end
st = StopTrigger_3_style();
r = R.PT; C = R.out.Car_PT;
t = C.Time - r.tStop; v = C.Data(:,1); x = C.Data(:,2); ic = C.Data(:,4);
xs = (x - r.xTrip)*1e3; xl = [-0.3 r.tStopped-r.tStop+0.3]; off = r.delay_ms/1e3;
f = st.figure('Stage 3: car after STOP', [1200 1000]);
tl = tiledlayout(f, 3, 1, 'TileSpacing', 'loose', 'Padding', 'compact');
st.title(tl, sprintf('Once STOP fires, the car comes to rest within %.0f mm', r.dTotal*1e3), ...
  sprintf('The relay cuts the motor in %.0f ms; the rest is the car coasting. Identical for all three sensors.', r.delay_ms));
marks = @(ax) [xline(ax, 0, '-', 'Color', st.ink, 'LineWidth', 1.4, 'DisplayName', 'STOP fires'), ...
               xline(ax, off, '--', 'Color', st.ref, 'LineWidth', 1.4, 'DisplayName', 'Motor off')];

ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
plot(ax, t, v*1e3, 'Color', st.PT, 'LineWidth', st.lw, 'DisplayName', 'Car speed'); marks(ax);
xlim(ax, xl); ylim(ax, [0 max(v)*1.2e3]); ylabel(ax, 'Speed [mm/s]'); title(ax, '1  Car speed'); st.legend(ax, 'northeast');

ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
plot(ax, t, ic*1e3, 'Color', st.PT, 'LineWidth', st.lw, 'DisplayName', 'Motor current'); marks(ax);
xlim(ax, xl); ylim(ax, [0 max(ic)*1.3e3]); ylabel(ax, 'Current [mA]'); title(ax, '2  Motor current drops to zero when the relay opens'); st.legend(ax, 'northeast');

ax = nexttile(tl); hold(ax,'on'); st.axes(ax);
plot(ax, t, xs, 'Color', st.PT, 'LineWidth', st.lw, 'DisplayName', 'Distance since STOP'); marks(ax);
yline(ax, r.dTotal*1e3, ':', 'Color', st.ink2, 'LineWidth', 1.3, 'HandleVisibility', 'off');
st.label(ax, xl(2), r.dTotal*1e3, sprintf('%.1f mm total  (%.1f mm relay delay + %.1f mm coast) ', r.dTotal*1e3, r.dDelay*1e3, r.dCoast*1e3), ...
  'HorizontalAlignment', 'right', 'VerticalAlignment', 'bottom', 'Color', st.ink, 'FontWeight', 'bold');
xlim(ax, xl); ylim(ax, [min(xs(t >= xl(1))) r.dTotal*1.35e3]); ylabel(ax, 'Distance [mm]'); xlabel(ax, 'Time from STOP [s]');
title(ax, '3  Distance travelled after STOP'); st.legend(ax, 'southeast');
st.export(f, pngFile);
end
