function T = StopTrigger_3_tests(testNames)
% Stage 3 robustness tests: what separates the LDR, phototransistor and photodiode on a real car.
%   T = StopTrigger_3_tests();               % all tests (~22 sims, about 9 min)
%   T = StopTrigger_3_tests('tolerance');    % one test: 'tolerance', 'supply' or 'noise'
%   StopTrigger_3_tests_plot(T);             % redraw the figure from saved results
%
% Tests (all three sensors run side by side in every simulation):
%   tolerance - each sensor's sensitivity scaled 50% to 150% while the circuit stays tuned for a
%               nominal part (part-to-part spread, ageing, LED brightness drift)
%   supply    - sensor supply Vcc +/-10% with the comparator reference held fixed
%   noise     - light noise level raised, three noise seeds each (flicker, bubbles, vibration)
% Results are saved in StopTrigger_3_tests_results.mat so tests can be run one at a time.

% Typical part-to-part spread of each sensor's sensitivity (placeholders, from typical datasheets)
TOL = struct('LDR', 0.30, 'PT', 0.50, 'PD', 0.10);

if nargin < 1, testNames = {'tolerance','supply','noise'}; end
testNames = cellstr(testNames);
run('StopTrigger_3_params.m');                 % apply car values, set StopTime
bn = 'StopTrigger_Bench_3';
mw = get_param(bn,'ModelWorkspace');
base = struct('Ald',getVariable(mw,'Ald'), 'Ipk',getVariable(mw,'Ipk'), 'Kpd',getVariable(mw,'Kpd'), ...
              'Vcc',getVariable(mw,'Vcc'), 'sigN',getVariable(mw,'sigN'));
resFile = fullfile(fileparts(mfilename('fullpath')), 'StopTrigger_3_tests_results.mat');
if isfile(resFile), S = load(resFile); T = S.T; else, T = struct(); end
T.TOL = TOL; T.tags = {'LDR','PT','PD'}; T.names = {'LDR','Phototransistor','Photodiode'};
T.tIdeal = idealTrip(mw); T.Vcc = getVariable(mw,'Vcc');

if any(strcmp(testNames,'tolerance'))
  g = [0.5 0.7 0.85 1 1.15 1.3 1.5];      % sensitivity factor: >1 means the sensor reads brighter than nominal
  in = repmat(Simulink.SimulationInput(bn), 1, numel(g));
  for i = 1:numel(g)
    in(i) = in(i).setVariable('Ald', base.Ald/g(i), 'Workspace', bn) ...   % lower LDR resistance = reads brighter
                 .setVariable('Ipk', base.Ipk*g(i), 'Workspace', bn) ...
                 .setVariable('Kpd', base.Kpd*g(i), 'Workspace', bn);
  end
  T.tolerance = runSet(in, T, 'g', g, 'Tolerance');
end

if any(strcmp(testNames,'supply'))
  V = base.Vcc*[0.9 0.95 1 1.05 1.1];
  in = repmat(Simulink.SimulationInput(bn), 1, numel(V));
  for i = 1:numel(V), in(i) = in(i).setVariable('Vcc', V(i), 'Workspace', bn); end
  T.supply = runSet(in, T, 'Vcc', V, 'Supply');
end

if any(strcmp(testNames,'noise'))
  lev = [0 0.01 0.02 0.04]; seeds = 1:3;
  [L, Sd] = ndgrid(lev, seeds); keep = ~(L == 0 & Sd > 1);       % no noise: one run is enough
  L = L(keep); Sd = Sd(keep);
  in = repmat(Simulink.SimulationInput(bn), 1, numel(L));
  for i = 1:numel(L)
    in(i) = in(i).setVariable('sigN', L(i), 'Workspace', bn).setVariable('seedN', Sd(i), 'Workspace', bn);
  end
  T.noise = runSet(in, T, 'sigN', L(:)', 'Noise');
  T.noise.seed = Sd(:)'; T.noise.levels = lev;
end

save(resFile, 'T');
StopTrigger_3_tests_plot(T);
end

function R = runSet(in, T, field, vals, label)
fprintf('\n%s test: %d simulations (about %.0f s each)...\n', label, numel(in), 23);
out = sim(in, 'ShowProgress', 'off', 'ShowSimulationManager', 'off', 'StopOnError', 'off');
n = numel(in); K = numel(T.tags);
R = struct(field, vals, 'xPast', nan(n,K), 'tStop', nan(n,K), 'atStart', false(n,K), 'never', false(n,K));
for i = 1:n
  if ~isempty(out(i).ErrorMessage), warning('Run %d failed: %s', i, out(i).ErrorMessage); continue, end
  for k = 1:K
    C = out(i).(['Car_' T.tags{k}]); S = out(i).(['S2_' T.tags{k}]);
    t = C.Time; x = C.Data(:,2);
    tS = S.Q.Time(find(S.Q.Data > 0.5*T.Vcc, 1));
    if isempty(tS), R.never(i,k) = true; continue, end              % light never got dark enough
    R.tStop(i,k) = tS;
    R.atStart(i,k) = tS < 0.5;                                      % fired before the car got going
    R.xPast(i,k) = (x(end) - interp1(t, x, T.tIdeal))*1e3;          % stop position vs ideal trip point [mm]
  end
  fprintf('  run %2d/%d done\n', i, n);
end
end

function tI = idealTrip(mw)
t0 = getVariable(mw,'t0'); tau = getVariable(mw,'tau'); Ts = getVariable(mw,'Tstart');
Te = getVariable(mw,'Tend'); Tt = getVariable(mw,'Ttrip');
tI = t0 + tau*log((Ts-Te)/(Tt-Te) - 1);
end
