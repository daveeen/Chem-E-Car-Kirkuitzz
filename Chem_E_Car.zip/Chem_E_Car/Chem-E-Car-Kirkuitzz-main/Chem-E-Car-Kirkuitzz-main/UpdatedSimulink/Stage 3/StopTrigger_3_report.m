function R = StopTrigger_3_report(out)
% Stage 3: stopping distance after STOP. Runs the bench unless a sim output is passed in.
tg = {'LDR','PT','PD'}; nm = {'LDR','Phototransistor','Photodiode'};
if nargin < 1
  if evalin('base','exist(''Car_LDR'',''var'') && exist(''S2_LDR'',''var'') && exist(''Car_PD'',''var'')')   % use the results of the last bench Run
    out = struct();
    for k = 1:3, out.(['Car_' tg{k}]) = evalin('base',['Car_' tg{k}]); out.(['S2_' tg{k}]) = evalin('base',['S2_' tg{k}]); end
  else
    out = sim('StopTrigger_Bench_3','ReturnWorkspaceOutputs','on');
  end
end
mw = get_param('StopTrigger_Bench_3','ModelWorkspace');
t0 = getVariable(mw,'t0'); tau = getVariable(mw,'tau'); Ts = getVariable(mw,'Tstart'); Te = getVariable(mw,'Tend'); Tt = getVariable(mw,'Ttrip');
tI = t0 + tau*log((Ts-Te)/(Tt-Te) - 1);          % ideal trip moment: light crosses T = 0.5
R.out = out; R.tags = tg; R.names = nm; R.tIdeal = tI;
for k = 1:3
  C = out.(['Car_' tg{k}]); S = out.(['S2_' tg{k}]);
  t = C.Time; v = C.Data(:,1); x = C.Data(:,2); w = C.Data(:,3);
  tS = S.Q.Time(find(S.Q.Data > getVariable(mw,'Vcc')/2, 1));   % STOP fires (latch Q high)
  ts = S.Im.Time; im = S.Im.Data;
  Is = mean(im(ts >= tS-0.3 & ts <= tS-0.02));       % running motor current
  tOff = ts(find(ts > tS & im < 0.05*Is, 1));         % motor current below 5%
  iS = find(t >= tS, 1); iO = find(t >= tOff, 1);
  r.name = nm{k}; r.tStop = tS; r.tOff = tOff; r.delay_ms = (tOff-tS)*1e3;
  r.vRun = mean(v(t >= tS-0.3 & t <= tS-0.02)); r.iRun = Is;
  r.wRun = mean(w(t >= tS-0.3 & t <= tS-0.02));
  r.xTrip = x(iS); r.xOff = x(iO);
  r.dDelay = x(iO)-x(iS); r.dCoast = x(end)-x(iO); r.dTotal = x(end)-x(iS);
  r.tStopped = t(find(t > tOff & v < 0.002, 1));
  r.lag_ms = (tS - tI)*1e3;                          % how late STOP fires after the ideal moment
  r.xPastIdeal = x(end) - interp1(t, x, tI);         % where the car stops, measured from the ideal trip point
  R.(tg{k}) = r;
end
% Hand check (same numbers as the model workspace)
m = getVariable(mw,'mcar'); rw = getVariable(mw,'rw'); Ng = getVariable(mw,'Ng'); Ke = getVariable(mw,'Ke');
Jm = getVariable(mw,'Jm'); T0 = getVariable(mw,'T0m'); Crr = getVariable(mw,'Crr'); g = getVariable(mw,'g');
Tf = T0 + Crr*m*g*rw/Ng;                 % friction torque at the motor shaft [N m]
Vp = getVariable(mw,'Vpack'); Rm = getVariable(mw,'Rm');
Rb = getVariable(mw,'Rbat');
Ih = Tf/Ke; vh = (Vp - Ih*(Rm+Rb+0.05))/Ke*rw/Ng;   % pack voltage, motor + battery resistance, 0.05 ohm contact
Meq = m + Jm*Ng^2/rw^2;                  % car mass plus rotor inertia seen at the wheel
Fd = T0*Ng/rw + Crr*m*g;                 % drag force at the wheel [N]
dh = 0.5*Meq*vh^2/Fd;
R.hand = struct('iRun',Ih,'vRun',vh,'Meq',Meq,'Fdrag',Fd,'dCoast',dh);
fprintf('\n%-24s %12s %16s %12s\n','','LDR','Phototransistor','Photodiode');
row = @(lab,f,fld,s) fprintf('%-24s %12s %16s %12s\n',lab,sprintf(f,R.LDR.(fld)*s),sprintf(f,R.PT.(fld)*s),sprintf(f,R.PD.(fld)*s));
row('STOP fires [s]', '%.4f', 'tStop', 1);
row('Late vs ideal [ms]', '%.1f', 'lag_ms', 1);
row('Motors off [ms]', '%.2f', 'delay_ms', 1);
row('Run speed [mm/s]', '%.1f', 'vRun', 1e3);
row('Run current [mA]', '%.1f', 'iRun', 1e3);
row('Relay delay [mm]', '%.2f', 'dDelay', 1e3);
row('Coast [mm]', '%.2f', 'dCoast', 1e3);
row('TOTAL after STOP [mm]', '%.2f', 'dTotal', 1e3);
row('Stops past ideal [mm]', '%.1f', 'xPastIdeal', 1e3);
row('Standstill [s]', '%.3f', 'tStopped', 1);
fprintf('Ideal trip moment (T = %.2f): %.4f s\n', Tt, tI);
fprintf('Hand check: run current %.1f mA, speed %.1f mm/s, coast %.2f mm\n', Ih*1e3, vh*1e3, dh*1e3);
[~, best] = min(abs([R.LDR.xPastIdeal R.PT.xPastIdeal R.PD.xPastIdeal]));
fprintf('Closest to the ideal stopping point: %s\n', nm{best});
end
