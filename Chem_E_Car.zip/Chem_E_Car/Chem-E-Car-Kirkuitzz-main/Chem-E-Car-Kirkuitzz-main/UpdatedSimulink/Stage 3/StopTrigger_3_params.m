% StopTrigger_3_params.m  --  EDIT THE VALUES BELOW, save, then run:  R = StopTrigger_3_run();
% Every value is a PLACEHOLDER until the mech team confirms it. Right-hand column says what it is.
P = struct();
%% Car (mech team)
P.m_car      = 2.0;    % [kg]       car mass, ready to run (chassis + battery + payload)
P.wheel_dia  = 60;     % [mm]       driven wheel diameter
P.gear_ratio = 100;    % [-]        motor turns per wheel turn (100 means 100:1)
P.Crr        = 0.02;   % [-]        rolling resistance coefficient (roll-down test with motor disconnected)
P.Dtarget    = 20;     % [m]        target distance (rules: 15 to 30 m, announced 1 h before)
%% Motor (datasheet or bench test)
P.V_nl       = 2.2;    % [V]        voltage the three no-load numbers below were measured at
P.rpm_nl     = 6736;   % [rpm]      no-load speed at V_nl
P.I_nl       = 0.050;  % [A]        no-load current at V_nl (measure with the gearbox fitted if you can)
P.R_motor    = 4.5;    % [ohm]      winding resistance (audit: Tamiya 70203, 0.67 A stall at 3 V)
P.J_rotor    = 1.0;    % [g cm^2]   rotor inertia (motor datasheet)
%% Battery (circuits / battery team)
P.V_pack     = 2.5;    % [V]        battery voltage with no load (VI curve: voltage at 0 A)
P.I_max      = 0.5;    % [A]        battery maximum current (VI curve: current at 0 V). Sets the internal
                       %            resistance R = V_pack/I_max. If 0.5 A is instead the current the
                       %            battery can supply while still holding 2.5 V, set I_max = Inf.
%% Stop circuit supply (circuits team): every sensor, the latch and the relay coil run from this
P.V_supply   = 2.5;    % [V]        stop-circuit supply rail
P.relay_Vrated = 3;    % [V]        relay coil rating (a 3 V coil: a 5 V coil will not pull in at 2.5 V)
P.relay_Rcoil  = 45;   % [ohm]      relay coil resistance (typical 3 V signal relay)
P.relay_tau    = 1.6e-3; % [s]      coil L/R time constant (same as the old 5 V relay)
P.fet_Vth    = 1.0;    % [V]        driver MOSFET gate threshold (logic-level part, turns fully on at 2.5 V)
P.fet_Rds    = 0.05;   % [ohm]      driver MOSFET on-resistance at 2.5 V gate drive
%% Phototransistor (circuits team)
P.pt_Ictrip  = 182e-6; % [A]        phototransistor current at the trip light level (measured in the bench model at
                       %            mid-rail on 2.5 V; effective gain ~83). Re-measure if the supply changes.
%% Photodiode (circuits team; typical BPW34-class values until bench-tested)
P.pd_resp    = 5e-6;   % [A per W/m^2] photocurrent per unit light (responsivity x active area, ~0.6 A/W x 7.5 mm^2)
P.pd_flux    = 8;      % [W/m^2]    light reaching the photodiode through a clear jar
P.pd_Rload   = 50e3;   % [ohm]      load resistor (photodiode reverse-biased from the supply into this)
P.pd_gain    = 1;      % [-]        op-amp gain after the load (1 = buffer)
%% ---- Derived values and model update (do not edit below) ----
bn = 'StopTrigger_Bench_3'; if ~bdIsLoaded(bn), load_system(bn); end
mw = get_param(bn,'ModelWorkspace');
g = 9.81; rw = P.wheel_dia/2/1000; Ng = P.gear_ratio;
w0 = P.rpm_nl*2*pi/60;                         % no-load shaft speed [rad/s]
Ke = (P.V_nl - P.I_nl*P.R_motor)/w0;           % back-EMF constant = torque constant [V s/rad]
T0 = Ke*P.I_nl;                                % no-load friction torque [N m]
Jm = P.J_rotor*1e-7;                           % [kg m^2]
Fd = T0*Ng/rw + P.Crr*P.m_car*g;               % drag force at the wheel [N]
Meq = P.m_car + Jm*Ng^2/rw^2;                  % car mass plus rotor inertia seen at the wheel [kg]
Itop = (T0 + P.Crr*P.m_car*g*rw/Ng)/Ke;        % running current [A]
Rbat = P.V_pack/P.I_max;                       % battery internal resistance [ohm]
Rloop = P.R_motor + Rbat + 0.05;               % motor + battery + relay contact [ohm]
v = (P.V_pack - Itop*Rloop)/Ke*rw/Ng;          % running speed [m/s]
dco = 0.5*Meq*v^2/Fd;                          % coast distance [m]
tmech = (Jm + P.m_car*rw^2/Ng^2)*Rloop/Ke^2;   % speed-up time constant [s]
tcoast = v*Meq/Fd;                             % time to coast to rest [s]
t0 = max(2, 0.5 + 6*tmech);                    % light fade starts after the car is up to speed
vals = {'mcar',P.m_car; 'rw',rw; 'Ng',Ng; 'Ke',Ke; 'Jm',Jm; 'T0m',T0; 'Crr',P.Crr; 'g',g; 'Vpack',P.V_pack; 'Rm',P.R_motor; 'Rbat',Rbat; 't0',t0};
for i = 1:size(vals,1), assignin(mw, vals{i,1}, vals{i,2}); end
% Stop-circuit thresholds, redesigned for the supply rail: every sensor trips at the same light level
% Ttrip. Falling signals (LDR, photodiode) feed the comparator's - input: Vref = Vth*(Rin+Rh)/Rh.
% The rising phototransistor signal feeds the + input through Rin: Vref = Vth*Rh/(Rin+Rh).
Vs = P.V_supply; Tt = getVariable(mw,'Ttrip'); Rin = getVariable(mw,'Rin'); Rh = getVariable(mw,'Rhyst');
Rfx = getVariable(mw,'Rfix'); Ald = getVariable(mw,'Ald'); gam = getVariable(mw,'gam'); GL = getVariable(mw,'GLDR');
VthL = GL*Vs*Rfx/(Ald*Tt^(-gam) + Rfx);        % LDR divider x gain at the trip light [V]
RpuPT = (Vs/2)/P.pt_Ictrip;                    % phototransistor pull-up: mid-rail at the trip light [ohm]
VthP = Vs - P.pt_Ictrip*RpuPT;                 % phototransistor output at the trip light [V]
VthD = P.pd_resp*P.pd_flux*Tt*P.pd_Rload*P.pd_gain;   % photodiode output at the trip light [V]
vals = {'Vcc',Vs; 'Vrail',Vs; 'VrefL',VthL*(Rin+Rh)/Rh; 'RpuPT',RpuPT; 'VrefP',VthP*Rh/(Rin+Rh); ...
        'Kpd',P.pd_resp; 'PhiPD',P.pd_flux; 'Rpd',P.pd_Rload; 'GPD',P.pd_gain; 'VrefD',VthD*(Rin+Rh)/Rh; ...
        'Rcoil',P.relay_Rcoil; 'Lcoil',P.relay_Rcoil*P.relay_tau; ...
        'Ipull',0.75*P.relay_Vrated/P.relay_Rcoil; 'Idrop',0.10*P.relay_Vrated/P.relay_Rcoil; ...   % must-operate 75%, must-release 10% of rated
        'VthFET',P.fet_Vth; 'RdsFET',P.fet_Rds; 'VgsFET',Vs};
for i = 1:size(vals,1), assignin(mw, vals{i,1}, vals{i,2}); end
if P.pd_resp*P.pd_flux*P.pd_Rload*P.pd_gain > 0.9*Vs, fprintf('  WARNING: photodiode output in a clear jar is above 90%% of the supply and will clip. Lower pd_Rload or pd_gain.\n'); end
if Vs/P.relay_Rcoil < 0.75*P.relay_Vrated/P.relay_Rcoil*1.05, fprintf('  WARNING: the relay coil gets less than 5%% above its pull-in current at %.1f V. Use a lower-voltage relay.\n', Vs); end
set_param(bn,'StopTime',num2str(ceil(t0 + 1.5*tcoast + 1.5)));
fprintf('\nCar values applied. Quick estimate (no simulation):\n');
fprintf('  running speed  %.1f mm/s,  running current %.1f mA\n', v*1e3, Itop*1e3);
fprintf('  battery: %.2f V at no load, %.2f V while running (internal %.1f ohm), start-up current %.0f mA (max %.0f mA)\n', ...
  P.V_pack, P.V_pack - Itop*Rbat, Rbat, P.V_pack/Rloop*1e3, min(P.I_max,99)*1e3);
fprintf('  coast distance %.1f mm,  coast time %.2f s\n', dco*1e3, tcoast);
fprintf('  %.0f m takes %.0f s at this speed (limit 120 s)\n', P.Dtarget, P.Dtarget/v);
if P.Dtarget/v > 110, fprintf('  WARNING: too slow for the target distance. Raise speed (lower gear ratio) or cut the distance.\n'); end
if v*1e3 < 20, fprintf('  WARNING: car barely moves. Check gear ratio, mass and motor numbers.\n'); end
