% StopTrigger_export  Run the stage 1 stop trigger bench and write the results to a CSV.
%   Usage:  StopTrigger_export            (writes StopTrigger_results.csv next to this file)
%           StopTrigger_export("out.csv")
function T = StopTrigger_export(csvFile)
    if nargin < 1, csvFile = fullfile(fileparts(mfilename("fullpath")), "StopTrigger_results.csv"); end
    bn = "StopTrigger_Bench_1a"; load_system(bn);
    o = sim(bn, "ReturnWorkspaceOutputs", "on");   % LDR, PT, PD each hold Vs, Va, STOP
    LDR = o.LDR; PT = o.PT; PD = o.PD; Tsig = o.Tsig;
    t = LDR.Vs.Time;
    at = @(ts) interp1(ts.Time, ts.Data, t);        % every signal on the LDR time base
    [tu, iu] = unique(Tsig.Time);
    T = table(t, interp1(tu, Tsig.Data(iu), t), LDR.Vs.Data, LDR.Va.Data, LDR.STOP.Data, ...
              at(PT.Vs), at(PT.Va), at(PT.STOP), at(PD.Vs), at(PD.Va), at(PD.STOP), ...
              VariableNames = ["time_s","T","LDR_Vs","LDR_Va","LDR_STOP","PT_Vs","PT_Va","PT_STOP","PD_Vs","PD_Va","PD_STOP"]);
    writetable(T, csvFile);
    fprintf("Wrote %d rows to %s\n", height(T), csvFile);
end
