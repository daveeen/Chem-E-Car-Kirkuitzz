function StopTrigger_plot(pngFile)
% Stage 1 figure: light, sensor voltage with clear/trip/dark levels and margins, and the comparator STOP output,
% for the LDR, phototransistor and photodiode on the 2.5 V stop-circuit supply.
if nargin < 1, pngFile = ''; end
bn = 'StopTrigger_Bench_1a'; load_system(bn);
o = sim(bn,'ReturnWorkspaceOutputs','on');            % fresh run, never stale workspace data
Tsig = o.Tsig; tend = Tsig.Time(end);
Vcc = getVariable(get_param(bn,'ModelWorkspace'),'Vcc');
tF = Tsig.Time(find(Tsig.Data < 0.9*Tsig.Data(1),1));  % moment the fade has clearly started
f = figure('Name','Stop trigger: LDR vs phototransistor vs photodiode','Color','w','Position',[60 60 1500 850]); try, theme(f,'light'); end
tl = tiledlayout(f,3,3,'TileSpacing','compact','Padding','compact');
title(tl,sprintf('Stage 1: optical stop trigger, sensor voltage, margins and STOP (%.1f V supply)',Vcc));
S = {o.LDR,'LDR','falls when dark','northeast','southeast'; o.PT,'Phototransistor','rises when dark','southeast','southeast'; ...
     o.PD,'Photodiode','falls when dark','northeast','southeast'};
ax0 = nexttile(tl,1,[1 3]); hold(ax0,'on'); grid(ax0,'on');
plot(ax0,Tsig.Time,Tsig.Data,'k','LineWidth',1.5,'DisplayName','Light reaching the sensor, T');
yline(ax0,0.5,'--r','DisplayName','Trip level, T = 0.5');
xlim(ax0,[0 tend]); ylabel(ax0,'Light T (1 = clear)'); xlabel(ax0,'Time [s]');
title(ax0,'Light fades as the reaction finishes'); legend(ax0,'Location','northeast');
for c = 1:3
  D = S{c,1}; nm = S{c,2}; dr = S{c,3};
  t = D.Vs.Time; vs = D.Vs.Data; stp = D.STOP.Data;
  k = find(stp > Vcc/2,1); ttrip = t(k); vtrip = vs(k);
  vclear = mean(vs(t >= 0.5*tF & t <= 0.9*tF)); vdark = mean(vs(t >= 0.9*tend));
  m1 = abs(vtrip-vclear); m2 = abs(vdark-vtrip);
  ax = nexttile(tl,3+c); hold(ax,'on'); grid(ax,'on');
  plot(ax,t,vs,'b','LineWidth',1.5,'DisplayName','Sensor voltage Vs');
  yline(ax,vclear,':k','LineWidth',1.3,'DisplayName',sprintf('Clear level %.2f V',vclear));
  yline(ax,vdark,'-.k','LineWidth',1.3,'DisplayName',sprintf('Dark level %.2f V',vdark));
  yline(ax,vtrip,'--r','LineWidth',1.3,'DisplayName',sprintf('Vs at trip %.2f V',vtrip));
  xline(ax,ttrip,'--r','HandleVisibility','off');
  ylim(ax,[0 Vcc]); xlim(ax,[0 tend]); xlabel(ax,'Time [s]'); ylabel(ax,'Sensor node Vs [V]');
  title(ax,sprintf('%s: Vs %s\nmargin: clear to trip %.2f V, trip to dark %.2f V',nm,dr,m1,m2));
  legend(ax,'Location',S{c,4});
  ax2 = nexttile(tl,6+c); hold(ax2,'on'); grid(ax2,'on');
  plot(ax2,t,stp,'r','LineWidth',1.5,'DisplayName','Comparator output STOP');
  xline(ax2,ttrip,'--k','LineWidth',1.2,'DisplayName',sprintf('STOP fires at %.3f s',ttrip));
  ylim(ax2,[-0.1 1.1]*Vcc); xlim(ax2,[0 tend]); xlabel(ax2,'Time [s]'); ylabel(ax2,sprintf('STOP [V]  (%.1f V = stop car)',Vcc));
  title(ax2,[nm ': comparator output']); legend(ax2,'Location',S{c,5});
end
if ~isempty(pngFile), exportgraphics(f,pngFile,'Resolution',150); end
end
